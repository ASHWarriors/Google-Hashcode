# -*- coding: utf-8 -*-
"""
Created on Thu Feb 25 22:58:56 2021

@author: anisumitaya
"""
f= open("b.txt")
raw_list= f.readlines()
f.close()
print(raw_list)
first_line= raw_list[0].rstrip("\n").split(" ")

range1= int(first_line[2])
range2=int(first_line[3])
streets= raw_list[1:1+range1]
cars= raw_list[1+range1:]
print(cars)
car=[]
for i in cars:
    car.append(i.rstrip())
print(first_line)    
print(car)
    
