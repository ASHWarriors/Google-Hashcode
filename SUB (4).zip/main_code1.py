# -*- coding: utf-8 -*-
"""
Created on Fri Feb 26 00:38:58 2021

@author: anisumitaya
"""
import filehandle

streets,cars,stime=filehandle.ret()
#print(streets)
print(cars)
route_to_inter=[]
for i in cars:
    stop=[]
    '''for t in streets:
        if i[1]==t[2]:
            stop.append(t[0])'''
    for j in i[1:]:
        for k in streets:
            if j==k[2]:
                stop.append(k[1])
    route_to_inter.append(stop)
print(route_to_inter,"route") 

import inout
begs,ends=inout.di()


inter_freq=[]
for ele in begs.keys():
    count=0
    for i in route_to_inter:
        if ele in i:
            count+=1
    inter_freq.append([ele,count])
print(inter_freq,"Inter freq")


    
Op = [str(len(begs.keys()))+'\n']
#print(ends)
for i in begs.keys():
    Op.append(i+'\n')
    Op.append(str(len(ends[i]))+'\n')
    
    for k in inter_freq:
        if i==k[0]:
            time=k[1]//len(ends[i])
            if time>stime:
                time=stime
            elif time==0:
                time=1
            else:
               pass 
                
                
            
            
            
            
    for j in ends[i]:
        Op.append(j+' '+str(time)+'\n')
print(Op) 

f=open("Subbnew.txt",'w')
f.writelines(Op)
f.close()


